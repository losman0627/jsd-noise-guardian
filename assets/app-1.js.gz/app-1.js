(() => {
  'use strict';

  const $ = id => document.getElementById(id);
  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
  const mean = a => a.length ? a.reduce((s, v) => s + v, 0) / a.length : NaN;
  const median = a => {
    const s = a.filter(Number.isFinite).slice().sort((x, y) => x - y);
    if (!s.length) return NaN;
    const m = Math.floor(s.length / 2);
    return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
  };
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const format = (v, digits = 0) => Number.isFinite(v) ? v.toFixed(digits) : '--';
  const userId = localStorage.getItem('jsd_user_id') || `u_${Math.random().toString(36).slice(2, 10)}`;
  localStorage.setItem('jsd_user_id', userId);

  const state = {
    stream: null, track: null, ctx: null, source: null, analyser: null,
    time: null, freq: null, spectrumFloor: null, raf: 0, measuring: false,
    instantDb: NaN, stableDb: NaN, maxDb: NaN, dominant: NaN, confidence: 0,
    topPeaks: [], freqHistory: [], dbHistory: [], chartHistory: [],
    expectedFreq: Number(localStorage.getItem('jsd_expected_freq')) || 0,
    currentCandidate: null, pendingCandidate: null, pendingCount: 0, lastUi: 0,
    map: null, mapLayer: null, mapItems: [], mapFilters: new Set(['official','citizen','report']), currentPosition: null, gasUrl: localStorage.getItem('jsd_gas_url') || '',
    anc: {
      lockedFreq: 0, on: false, busy: false, osc: null, delay: null, gain: null,
      baselineDb: NaN, residualDb: NaN, phase: 180, history: [], monitor: null,
      badCount: 0, tuneToken: 0
    }
  };

  function toast(message) {
    const el = $('toast');
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => el.classList.remove('show'), 2400);
  }

  function setTheme(theme) {
    document.body.dataset.theme = theme;
    localStorage.setItem('jsd_theme', theme);
    document.querySelector('meta[name="theme-color"]').setAttribute('content', theme === 'dark' ? '#0b1322' : '#f4f6fb');
  }
  setTheme(localStorage.getItem('jsd_theme') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
  $('themeButton').addEventListener('click', () => setTheme(document.body.dataset.theme === 'dark' ? 'light' : 'dark'));

  function navigate(name) {
    document.querySelectorAll('.screen').forEach(x => x.classList.toggle('active', x.id === `screen-${name}`));
    document.querySelectorAll('.tab').forEach(x => x.classList.toggle('active', x.dataset.nav === name));
    window.scrollTo({top: 0, behavior: 'smooth'});
    if (name === 'map') initMap();
    if (name === 'news') loadNews();
  }
  document.querySelectorAll('[data-nav]').forEach(x => x.addEventListener('click', () => navigate(x.dataset.nav)));
  setTimeout(() => $('splash')?.classList.add('done'), 3300);

  function grade(db) {
    if (!Number.isFinite(db)) return ['대기 중', 'var(--muted2)'];
    if (db < 45) return ['조용함', 'var(--good)'];
    if (db < 60) return ['보통', 'var(--blue)'];
    if (db < 70) return ['주의', 'var(--warn)'];
    if (db < 80) return ['높음', 'var(--bad)'];
    return ['매우 높음', 'var(--bad)'];
  }

  function constraintsFor(deviceId, exact = true) {
    const raw = exact ? {exact: false} : false;
    return {
      echoCancellation: raw,
      noiseSuppression: raw,
      autoGainControl: raw,
      channelCount: {ideal: 1},
      sampleRate: {ideal: 48000},
      ...(deviceId ? {deviceId: exact ? {exact: deviceId} : {ideal: deviceId}} : {})
    };
  }

  async function requestMicrophone(deviceId = '') {
    try {
      return await navigator.mediaDevices.getUserMedia({audio: constraintsFor(deviceId, true), video: false});
    } catch (error) {
      if (error && ['OverconstrainedError', 'TypeError'].includes(error.name)) {
        return navigator.mediaDevices.getUserMedia({audio: constraintsFor(deviceId, false), video: false});
      }
      throw error;
    }
  }

  async function startMeasurement(deviceId = $('micSelect').value) {
    if (state.measuring) return true;
    if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
      throw new Error('마이크 기능은 HTTPS 주소와 지원 브라우저에서만 사용할 수 있습니다.');
    }
    $('measureStatus').textContent = '마이크를 연결하고 있습니다…';
    let stream;
    try {
      stream = await requestMicrophone(deviceId);
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) throw new Error('Web Audio API를 지원하지 않는 브라우저입니다.');
      const ctx = new AudioCtx({latencyHint: 'interactive'});
      await ctx.resume();
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 32768;
      analyser.smoothingTimeConstant = 0.08;
      analyser.minDecibels = -110;
      analyser.maxDecibels = -10;
      source.connect(analyser);

      state.stream = stream;
      state.track = stream.getAudioTracks()[0];
      state.ctx = ctx;
      state.source = source;
      state.analyser = analyser;
      state.time = new Float32Array(analyser.fftSize);
      state.freq = new Float32Array(analyser.frequencyBinCount);
      state.spectrumFloor = null;
      state.measuring = true;
      state.stableDb = state.instantDb = state.maxDb = NaN;
      state.dominant = NaN;
      state.freqHistory = [];
      state.dbHistory = [];
      state.chartHistory = [];
      state.lastUi = 0;
      state.currentCandidate = null;
      state.pendingCandidate = null;
      state.pendingCount = 0;

      state.track.addEventListener('ended', () => stopMeasurement('마이크 연결이 종료되었습니다.'));
      $('startMeasure').disabled = true;
      $('stopMeasure').disabled = false;
      $('saveLocal').disabled = false;
      $('saveServer').disabled = !isGasUrl(state.gasUrl);
      if ($('saveMap')) $('saveMap').disabled = false;
      $('measureStatus').textContent = '측정 중 · ANC 출력 전에는 전체 피크를 분석합니다.';
      await refreshDevices();
      renderTrackSettings();
      state.raf = requestAnimationFrame(loop);
      return true;
    } catch (error) {
      if (stream) stream.getTracks().forEach(t => t.stop());
      stopMeasurement('측정을 시작하지 못했습니다.');
      throw error;
    }
  }

  function stopMeasurement(message = '측정을 정지했습니다.') {
    stopAnc('측정이 중단되어 ANC도 정지했습니다.', false);
    state.measuring = false;
    cancelAnimationFrame(state.raf);
    if (state.stream) state.stream.getTracks().forEach(t => t.stop());
    if (state.source) { try { state.source.disconnect(); } catch (_) {} }
    if (state.ctx) state.ctx.close().catch(() => {});
    Object.assign(state, {stream: null, track: null, ctx: null, source: null, analyser: null, time: null, freq: null});
    $('startMeasure').disabled = false;
    $('stopMeasure').disabled = true;
    $('saveLocal').disabled = true;
    $('saveServer').disabled = true;
    if ($('saveMap')) $('saveMap').disabled = true;
    $('measureStatus').textContent = message;
    $('trackSettings').textContent = '마이크가 정지되었습니다.';
    $('homeMic').textContent = '마이크 미사용';
  }

  function frameDb(buffer, calibration) {
    const count = Math.min(4096, buffer.length);
    const start = buffer.length - count;
    let avg = 0;
    for (let i = start; i < buffer.length; i++) avg += buffer[i];
    avg /= count;
    let sum = 0;
    for (let i = start; i < buffer.length; i++) {
      const v = buffer[i] - avg;
      sum += v * v;
    }
    const rms = Math.sqrt(sum / count);
    return 20 * Math.log10(Math.max(rms, 1e-9)) + calibration;
  }

  function toneAmplitudeDb(buffer, frequency, sampleRate) {
    if (!buffer || !Number.isFinite(frequency) || frequency < 20 || frequency > sampleRate / 2) return -120;
    const count = Math.min(8192, buffer.length);
    const start = buffer.length - count;
    const w = 2 * Math.PI * frequency / sampleRate;
    let sumSin = 0, sumCos = 0, weightSum = 0;
    for (let n = 0; n < count; n++) {
      const win = 0.5 - 0.5 * Math.cos(2 * Math.PI * n / (count - 1));
      const x = buffer[start + n] * win;
      sumCos += x * Math.cos(w * n);
      sumSin += x * Math.sin(w * n);
      weightSum += win;
    }
    const amp = 2 * Math.hypot(sumCos, sumSin) / Math.max(weightSum, 1e-9);
    return 20 * Math.log10(Math.max(amp, 1e-9));
  }

  function localCorrelation(buffer, frequency, sampleRate) {
    const lag = sampleRate / frequency;
    const whole = Math.floor(lag);
    const frac = lag - whole;
    const count = Math.min(3072, buffer.length - whole - 2);
    if (count < 512) return 0;
    const start = buffer.length - count - whole - 2;
    let mx = 0, my = 0;
    for (let i = 0; i < count; i++) {
      const x = buffer[start + i];
      const j = start + i + whole;
      const y = buffer[j] * (1 - frac) + buffer[j + 1] * frac;
      mx += x; my += y;
    }
    mx /= count; my /= count;
    let num = 0, dx = 0, dy = 0;
    for (let i = 0; i < count; i++) {
      const x = buffer[start + i] - mx;
      const j = start + i + whole;
      const y = buffer[j] * (1 - frac) + buffer[j + 1] * frac - my;
      num += x * y; dx += x * x; dy += y * y;
    }
    return dx > 1e-12 && dy > 1e-12 ? clamp(num / Math.sqrt(dx * dy), -1, 1) : 0;
  }

  function analyzeSpectrum() {
    state.analyser.getFloatFrequencyData(state.freq);
    const sr = state.ctx.sampleRate;
    const fftSize = state.analyser.fftSize;
    const binHz = sr / fftSize;
    const minBin = Math.max(2, Math.ceil(40 / binHz));
    const maxBin = Math.min(state.freq.length - 3, Math.floor(600 / binHz));
    if (!state.spectrumFloor || state.spectrumFloor.length !== state.freq.length) {
      state.spectrumFloor = Float32Array.from(state.freq);
    }
    const values = [];
    for (let i = minBin; i <= maxBin; i++) values.push(state.freq[i]);
    const globalFloor = median(values);
    const radius = Math.max(10, Math.round(35 / binHz));
    const guard = Math.max(2, Math.round(5 / binHz));
    const candidates = [];

    for (let k = minBin + 2; k <= maxBin - 2; k++) {
      const b = state.freq[k];
      if (!(b > state.freq[k - 1] && b >= state.freq[k + 1])) continue;
      const around = [];
      for (let i = Math.max(minBin, k - radius); i <= Math.min(maxBin, k + radius); i++) {
        if (Math.abs(i - k) > guard) around.push(state.freq[i]);
      }
      const localFloor = around.length ? median(around) : globalFloor;
      const prominence = b - localFloor;
      const novelty = b - state.spectrumFloor[k];
      if (b < -102 || (prominence < 4.5 && novelty < 7)) continue;
      const a = state.freq[k - 1], c = state.freq[k + 1];
      const den = a - 2 * b + c;
      const delta = Math.abs(den) > 1e-6 ? clamp(0.5 * (a - c) / den, -0.5, 0.5) : 0;
      const f = (k + delta) * binHz;
      const corr = Math.max(0, localCorrelation(state.time, f, sr));
      const continuity = Number.isFinite(state.dominant) ? Math.max(0, 5 - Math.abs(f - state.dominant) / Math.max(3, state.dominant * 0.018)) : 0;
      const expectedBonus = state.expectedFreq ? Math.max(0, 16 - Math.abs(f - state.expectedFreq) * 0.8) : 0;
      const score = prominence * 1.9 + Math.max(0, novelty) * 0.7 + Math.max(0, b - globalFloor) * 0.25 + corr * 6 + continuity + expectedBonus;
      candidates.push({f, bin: k, db: b, prominence, novelty, corr, score});
    }
    candidates.sort((x, y) => y.score - x.score);
    state.topPeaks = candidates.slice(0, 5);

    let selected = null;
    if (state.expectedFreq) {
      const radiusHz = Math.max(14, state.expectedFreq * 0.06);
      selected = candidates.filter(x => Math.abs(x.f - state.expectedFreq) <= radiusHz).sort((x, y) => y.db - x.db)[0] || null;
      if (!selected) {
        const exactDb = toneAmplitudeDb(state.time, state.expectedFreq, sr);
        selected = {f: state.expectedFreq, db: exactDb, prominence: 0, novelty: 0, corr: 0, score: 0, tracked: true};
      }
    } else {
      selected = candidates[0] || null;
    }

    if (selected) {
      const proposed = selected.f;
      if (!Number.isFinite(state.dominant) || Math.abs(proposed - state.dominant) <= Math.max(6, state.dominant * 0.035) || state.expectedFreq) {
        state.dominant = Number.isFinite(state.dominant) ? state.dominant * 0.58 + proposed * 0.42 : proposed;
        state.pendingCandidate = null; state.pendingCount = 0;
      } else {
        const samePending = state.pendingCandidate && Math.abs(proposed - state.pendingCandidate) < Math.max(5, proposed * 0.025);
        state.pendingCandidate = proposed;
        state.pendingCount = samePending ? state.pendingCount + 1 : 1;
        if (state.pendingCount >= 4) {
          state.dominant = proposed;
          state.pendingCandidate = null; state.pendingCount = 0;
          state.freqHistory = [];
        }
      }
      const second = candidates[1];
      const gap = second ? selected.score - second.score : 10;
      state.confidence = clamp(0.28 + Math.min(Math.max(selected.prominence, 0), 24) / 42 + Math.min(Math.max(gap, 0), 12) / 30 + (state.expectedFreq ? 0.18 : 0), 0, 1);
      state.freqHistory.push(state.dominant);
      if (state.freqHistory.length > 28) state.freqHistory.shift();
    } else {
      state.confidence = Math.max(0, state.confidence - 0.1);
    }

    for (let i = minBin; i <= maxBin; i++) {
      const target = state.freq[i];
      const rate = target < state.spectrumFloor[i] ? 0.08 : 0.004;
      state.spectrumFloor[i] += (target - state.spectrumFloor[i]) * rate;
    }
  }

  function loop(ts) {
    if (!state.measuring) return;
    state.analyser.getFloatTimeDomainData(state.time);
    state.instantDb = frameDb(state.time, Number($('calibration').value));
    analyzeSpectrum();
    const speed = Number($('responseSpeed')?.value || 1);
    const interval = speed === 1 ? 220 : speed === 2 ? 130 : 80;
    if (!state.lastUi || ts - state.lastUi >= interval) {
      const target = state.instantDb;
      const attack = speed === 1 ? 0.52 : speed === 2 ? 0.68 : 0.82;
      const release = speed === 1 ? 0.16 : speed === 2 ? 0.27 : 0.38;
      const alpha = !Number.isFinite(state.stableDb) || target >= state.stableDb ? attack : release;
      state.stableDb = Number.isFinite(state.stableDb) ? state.stableDb + (target - state.stableDb) * alpha : target;
      state.stableDb = clamp(state.stableDb, 10, 120);
      state.maxDb = Number.isFinite(state.maxDb) ? Math.max(state.maxDb, state.instantDb) : state.instantDb;
      state.dbHistory.push(state.stableDb);
      if (state.dbHistory.length > 180) state.dbHistory.shift();
      state.chartHistory.push({db: state.stableDb, f: state.dominant, t: Date.now()});
      if (state.chartHistory.length > 150) state.chartHistory.shift();
      renderMeasurement();
      state.lastUi = ts;
    }
    state.raf = requestAnimationFrame(loop);
  }

  function noiseClass() {
    const f = state.dominant;
    const tonal = state.topPeaks[0]?.prominence || 0;
    if (!Number.isFinite(f)) return {type:'측정 전', anc:false};
    if (f <= 350 && tonal >= 5) return {type:f < 120 ? '저주파 엔진·기계음' : '강한 저주파 톤', anc:true};
    if (f < 500) return {type:'중저역 생활·공사음', anc:false};
    return {type:'복합 생활소음', anc:false};
  }

  function renderMeasurement() {
    const db = state.stableDb;
    const [label, color] = grade(db);
    const noise = noiseClass();
    const score = Number.isFinite(db) ? clamp(Math.round(100 - (db - 38) * 1.55), 0, 100) : NaN;
    const avg = mean(state.dbHistory.slice(-80));
    const stability = state.freqHistory.length > 4 && Number.isFinite(state.dominant)
      ? clamp(100 - (median(state.freqHistory.slice(-16).map(v => Math.abs(v - median(state.freqHistory.slice(-16))))) / Math.max(1, state.dominant * .02)) * 100, 0, 100)
      : state.confidence * 100;
    $('dbValue').textContent = format(db);
    $('instantDb').textContent = format(state.instantDb);
    $('maxDb').textContent = format(state.maxDb);
    $('dominantFreq').textContent = format(state.dominant);
    $('freqConfidence').textContent = format(state.confidence * 100);
    if ($('dbAvg')) $('dbAvg').textContent = format(avg);
    if ($('freqStability')) $('freqStability').textContent = format(stability);
    $('dbGrade').textContent = label;
    $('dbGrade').style.color = color;
    const circumference = 405;
    const p = clamp((db - 20) / 80, 0, 1);
    $('gaugeFill').style.strokeDashoffset = String(circumference * (1 - p));
    $('gaugeFill').style.stroke = color;
    $('homeDb').textContent = format(db);
    $('homeFreq').textContent = format(state.dominant);
    if ($('homeType')) $('homeType').textContent = noise.type;
    if ($('homeScore')) $('homeScore').textContent = Number.isFinite(score) ? score : '--';
    if ($('homeAnc') && !state.anc.lockedFreq) $('homeAnc').textContent = noise.anc ? '가능' : '제한적';
    $('homeSummary').textContent = Number.isFinite(db)
      ? (score >= 75 ? '현재는 비교적 편안한 소음 환경입니다.' : score >= 50 ? '오래 노출되기보다 잠시 조용한 곳에서 쉬어 보세요.' : '소음 노출을 줄이고 휴식 시간을 확보해 주세요.')
      : '측정을 시작하면 소음 크기와 주요 주파수를 보여드립니다.';
    if ($('homePeak')) $('homePeak').textContent = `${format(state.dominant)} Hz`;
    if ($('homePeakStatus')) $('homePeakStatus').textContent = Number.isFinite(state.dominant) ? noise.type : '측정 대기';
    if ($('micPeak')) $('micPeak').textContent = `${format(state.dominant)} Hz`;
    if ($('micPeakState')) $('micPeakState').textContent = Number.isFinite(state.dominant) ? `${noise.type} · 안정도 ${format(stability)}%` : '측정 대기';
    if ($('ancCurrentFreq')) $('ancCurrentFreq').textContent = format(state.dominant);
    if ($('ancPeakState')) $('ancPeakState').textContent = Number.isFinite(state.dominant) ? `${noise.type} · ${noise.anc ? 'ANC 후보' : '수동 저감 우선'}` : '측정 대기';
    renderSpectrum();
    renderHistory();
    renderPeakList();
    if (state.anc.on && state.anc.lockedFreq) updateAncResidual();
  }

  function drawCanvasBase(ctx, canvas) {
    const dark = document.body.dataset.theme === 'dark';
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = dark ? '#101b30' : '#f2f5fa';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = dark ? '#2a3c5d' : '#dce3ed';
    ctx.lineWidth = 1;
  }

  function renderSpectrum() {
    const canvas = $('spectrumCanvas'), ctx = canvas.getContext('2d');
    drawCanvasBase(ctx, canvas);
    if (!state.freq || !state.ctx) return;
    const sr = state.ctx.sampleRate, n = state.analyser.fftSize, binHz = sr / n;
    const min = Math.ceil(40 / binHz), max = Math.floor(600 / binHz);
    const width = canvas.width, height = canvas.height;
    const floor = -105, ceiling = -25;
    ctx.beginPath();
    for (let px = 0; px < width; px++) {
      const f = 40 + (560 * px / (width - 1));
      const bin = clamp(Math.round(f / binHz), min, max);
      const value = state.freq[bin];
      const y = height - clamp((value - floor) / (ceiling - floor), 0, 1) * (height - 18) - 8;
      if (px === 0) ctx.moveTo(px, y); else ctx.lineTo(px, y);
    }
    ctx.strokeStyle = '#397fc0'; ctx.lineWidth = 3; ctx.stroke();
    const markers = [];
    if (Number.isFinite(state.dominant)) markers.push({f: state.dominant, color: '#ffd400', label: `${Math.round(state.dominant)}Hz`});
    if (state.expectedFreq) markers.push({f: state.expectedFreq, color: '#278a5b', label: `추적 ${Math.round(state.expectedFreq)}Hz`});
    if (state.anc.lockedFreq) markers.push({f: state.anc.lockedFreq, color: '#d94747', label: `잠금 ${Math.round(state.anc.lockedFreq)}Hz`});
    markers.forEach(m => {
      const x = (m.f - 40) / 560 * width;
      ctx.strokeStyle = m.color; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke();
      ctx.fillStyle = m.color; ctx.font = 'bold 24px sans-serif'; ctx.fillText(m.label, clamp(x + 7, 8, width - 170), 28);
    });
  }

  function drawFrequencyFlow(canvas) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    drawCanvasBase(ctx, canvas);
    const data = state.chartHistory.filter(d => Number.isFinite(d.f));
    if (data.length < 2) return;
    const w = canvas.width, h = canvas.height;
    ctx.strokeStyle = '#397fc0'; ctx.lineWidth = 3; ctx.beginPath();
    data.forEach((d, i) => {
      const x = i / Math.max(data.length - 1, 1) * w;
      const y = h - clamp((d.f - 40) / 560, 0, 1) * (h - 18) - 9;
      if (!i) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }); ctx.stroke();
    if (Number.isFinite(state.dominant)) {
      const y = h - clamp((state.dominant - 40) / 560, 0, 1) * (h - 18) - 9;
      ctx.fillStyle = '#ffd400'; ctx.beginPath(); ctx.arc(w - 8, y, 6, 0, Math.PI * 2); ctx.fill();
    }
  }

  function renderHistory() {
    drawFrequencyFlow($('historyCanvas'));
    drawFrequencyFlow($('homeFreqCanvas'));
    drawFrequencyFlow($('ancFlowCanvas'));
  }

  function renderPeakList() {
    const peaks = state.topPeaks.slice(0, 3);
    $('peakList').innerHTML = peaks.length ? peaks.map((p, i) => `<span>${i + 1}위 ${Math.round(p.f)}Hz · ${p.db.toFixed(1)}dBFS</span>`).join('') : '<span>뚜렷한 피크가 없습니다.</span>';
    $('spectrumMode').textContent = state.expectedFreq ? `${Math.round(state.expectedFreq)}Hz 주변 추적` : '자동 피크 탐색';
  }

  async function refreshDevices() {
    if (!navigator.mediaDevices?.enumerateDevices) return;
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const inputs = devices.filter(d => d.kind === 'audioinput');
      const outputs = devices.filter(d => d.kind === 'audiooutput');
      const selectedMic = $('micSelect').value;
      $('micSelect').innerHTML = '<option value="">시스템 기본 마이크</option>' + inputs.map((d, i) => `<option value="${escapeHtml(d.deviceId)}">${escapeHtml(d.label || `마이크 ${i + 1}`)}</option>`).join('');
      if ([...$('micSelect').options].some(o => o.value === selectedMic)) $('micSelect').value = selectedMic;
      const selectedOut = $('outputSelect').value;
      $('outputSelect').innerHTML = '<option value="">시스템 기본 출력</option>' + outputs.map((d, i) => `<option value="${escapeHtml(d.deviceId)}">${escapeHtml(d.label || `출력 ${i + 1}`)}</option>`).join('');
      if ([...$('outputSelect').options].some(o => o.value === selectedOut)) $('outputSelect').value = selectedOut;
    } catch (_) {}
  }

  function renderTrackSettings() {
    if (!state.track) return;
    const s = state.track.getSettings ? state.track.getSettings() : {};
    const lines = [
      `입력 장치: ${state.track.label || '장치명 확인 불가'}`,
      `에코 제거: ${settingText(s.echoCancellation)}`,
      `소음 억제: ${settingText(s.noiseSuppression)}`,
      `자동 이득: ${settingText(s.autoGainControl)}`,
      `샘플레이트: ${s.sampleRate || state.ctx?.sampleRate || '확인 불가'} Hz`,
      `채널 수: ${s.channelCount || '확인 불가'}`
    ];
    $('trackSettings').textContent = lines.join('\n');
    $('homeMic').textContent = state.track.label || '마이크 연결됨';
  }
  function settingText(v) { return v === true ? '켜짐' : v === false ? '꺼짐' : '확인 불가'; }
  function escapeHtml(v) { return String(v ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }

  function applyExpectedFrequency(value) {
    const f = Number(value);
    state.expectedFreq = Number.isFinite(f) && f >= 40 && f <= 600 ? f : 0;
    if (state.expectedFreq) {
      localStorage.setItem('jsd_expected_freq', String(state.expectedFreq));
      $('expectedFrequency').value = String(state.expectedFreq);
      toast(`${Math.round(state.expectedFreq)}Hz 주변 추적을 시작합니다.`);
    } else {
      localStorage.removeItem('jsd_expected_freq');
      $('expectedFrequency').value = '';
      toast('자동 피크 탐색으로 전환했습니다.');
    }
    state.dominant = NaN; state.freqHistory = [];
  }
  if (state.expectedFreq) $('expectedFrequency').value = state.expectedFreq;
  $('applyExpected').addEventListener('click', () => applyExpectedFrequency($('expectedFrequency').value));
  $('clearExpected').addEventListener('click', () => applyExpectedFrequency(0));
  document.querySelectorAll('[data-expected]').forEach(x => x.addEventListener('click', () => applyExpectedFrequency(x.dataset.expected)));
  $('calibration').addEventListener('input', () => { $('calibrationOutput').textContent = `${$('calibration').value} dB`; });
  $('responseSpeed')?.addEventListener('input', () => { $('responseSpeedLabel').textContent = ({1:'안정형',2:'균형형',3:'빠른형'})[$('responseSpeed').value] || '안정형'; });

  $('startMeasure').addEventListener('click', async () => {
    try { await startMeasurement(); } catch (e) { toast(e.message || String(e)); $('measureStatus').textContent = e.message || String(e); }
  });
  $('stopMeasure').addEventListener('click', () => stopMeasurement());
  $('refreshDevices').addEventListener('click', async () => { await refreshDevices(); toast('오디오 장치 목록을 새로고침했습니다.'); });
  $('reconnectMic').addEventListener('click', async () => {
    const id = $('micSelect').value;
    if (state.measuring) stopMeasurement('마이크를 다시 연결합니다.');
    try { await startMeasurement(id); toast('선택한 입력 장치로 다시 연결했습니다.'); } catch (e) { toast(e.message || String(e)); }
  });

  async function captureTarget(manual = 0) {
    if (!state.measuring) await startMeasurement();
    let f = Number(manual) || state.expectedFreq || state.dominant;
    if (!Number.isFinite(f) || f < 40 || f > 600) throw new Error('40~600Hz 범위의 목표 주파수를 확인하지 못했습니다.');
    if (!manual && !state.expectedFreq && state.confidence < 0.38) throw new Error('주파수 신뢰도가 낮습니다. 수동 목표 주파수를 입력하세요.');
    state.anc.lockedFreq = Math.round(f * 10) / 10;
    $('lockedFrequency').textContent = `${format(state.anc.lockedFreq, 1)} Hz`;
    $('lockState').textContent = 'ANC 실행 중에도 이 목표는 자동으로 바뀌지 않습니다.';
    $('homeAnc').textContent = `${format(state.anc.lockedFreq, 1)} Hz 잠금`;
    $('manualAncFrequency').value = String(Math.round(state.anc.lockedFreq));
    renderSpectrum();
    return state.anc.lockedFreq;
  }

  function unlockTarget() {
    if (state.anc.on || state.anc.busy) stopAnc('목표 잠금을 해제해 ANC를 정지했습니다.');
    state.anc.lockedFreq = 0;
    $('lockedFrequency').textContent = '-- Hz';
    $('lockState').textContent = '아직 잠그지 않았습니다.';
    $('homeAnc').textContent = '잠금 안 됨';
    renderSpectrum();
  }

  function setAncPhase(phase) {
    state.anc.phase = ((Number(phase) % 360) + 360) % 360;
    $('ancPhase').value = String(Math.round(state.anc.phase));
    $('ancPhaseValue').textContent = `${Math.round(state.anc.phase)}°`;
    $('phaseValue').textContent = format(state.anc.phase);
    if (state.anc.delay && state.anc.lockedFreq) {
      const seconds = state.anc.phase / 360 / state.anc.lockedFreq;
      state.anc.delay.delayTime.setTargetAtTime(seconds, state.ctx.currentTime, 0.015);
    }
  }

  function outputGainValue() {
    const percent = Number($('ancOutput').value);
